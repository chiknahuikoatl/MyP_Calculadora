package Modelo;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Alejandro Hernández Mora <alejandrohmora@ciencias.unam.mx>
 */ 
public class NodoParentesis extends NodoOperador {

    /**
     *
     */
    public NodoParentesis() {
        super();
        precedence = 2;
    }

    /**
     *
     * @return
     */
    @Override
    public double evalua() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
